@echo off
echo Building debug APK...
gradle assembleDebug
echo.
echo APK path:
echo app\build\outputs\apk\debug\app-debug.apk
pause
