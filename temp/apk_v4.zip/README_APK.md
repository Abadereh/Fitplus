# ساخت APK کالری شمار من - نسخه 56

این پروژه یک Wrapper خیلی سبک WebView برای آخرین نسخه اصلاحی برنامه است.
فایل اصلی برنامه داخل این مسیر قرار دارد:

app/src/main/assets/index.html

## روش پیشنهادی ساده
1. Android Studio را نصب کن.
2. پوشه پروژه را باز کن.
3. صبر کن Gradle Sync کامل شود.
4. از منوی Build گزینه Build APK(s) را بزن.
5. خروجی را اینجا پیدا می‌کنی:

app/build/outputs/apk/debug/app-debug.apk

## روش سبک تر با خط فرمان
نیازها:
- JDK 17
- Android SDK Command-Line Tools
- Android SDK Platform Tools
- Android SDK Build Tools
- Gradle

بعد داخل ریشه پروژه بزن:

gradle assembleDebug

یا روی ویندوز فایل build_apk.bat را اجرا کن.

## انتشار واقعی
برای انتشار در بازار یا مایکت، Debug APK کافی نیست.
باید Release APK بسازی و با Keystore خودت امضا کنی.
در Android Studio از مسیر Build > Generate Signed App Bundle / APK استفاده کن.

## v2 / app content v55
- محتوای وب‌اپ داخل WebView به cal_v55 به‌روزرسانی شد.
- دکمه «استخراج ریز مصرف» با خروجی TXT روزانه، ۷ روز اخیر و ۳۰ روز اخیر اضافه شد.


## v3 / app content v56
- محتوای وب اپ به آخرین نسخه اصلاحی cal_v56 به روز شد.
- واحدهای دقیق نان سنگک و نان لواش اضافه شد.

## v4 / GitHub Actions
- فایل `.github/workflows/build-apk.yml` اضافه شد تا بتوانی بدون نصب Android SDK روی لپ تاپ، APK را در GitHub بسازی.
- راهنمای فارسی `README_GITHUB_ACTIONS_FA.md` اضافه شد.
